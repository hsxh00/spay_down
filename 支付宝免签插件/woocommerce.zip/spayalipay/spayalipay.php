<?php
/**
 * Plugin Name: SPAY支付宝免签插件
 * Plugin URI: http://spay.swapteam.cn
 * Description: SPAY支付宝免签插件
 * Version: 1.0
 * Author: 黑色小河
 * Author URI: http://spay.swapteam.cn
 **/


add_action('plugins_loaded', 'init_spayalipay_gateway_class' );
add_filter('woocommerce_payment_gateways', 'add_spayalipay_gateway_class');

function add_spayalipay_gateway_class( $methods ) {
	$methods[] = 'WC_Gateway_spayalipay_Gateway'; 
	return $methods;
}
function init_spayalipay_gateway_class() {
	class WC_Gateway_spayalipay_Gateway extends WC_Payment_Gateway{
		public function __construct(){
			//die();
			$this->id= 'spayalipay';
			$this->icon= apply_filters('woocommerce_spayalipay_icon',plugins_url('', __FILE__ ).'/img/alipay.png');
			$this->has_fields= false;
			$this->method_title='spay支付宝免签';
			$this->init_form_fields();
			$this->init_settings();
			$this->title= $this->settings['title'];
			$this->description= $this->settings['description'];
			$this->alipayUid= $this->settings['alipayUid'];
			$this->alipayKey= $this->settings['alipayKey'];
			//die(print_r($this,1));
			add_action('woocommerce_update_options_payment_gateways_'.$this->id,array(&$this, 'process_admin_options'));
		}
		
		public function admin_options(){
			?><h3>spay支付宝免签</h3><p></p><table class="form-table"><?php $this->generate_settings_html();?></table><?php
		}

		function init_form_fields(){
			$this->form_fields= array(
				'enabled'		=>array('title'=>'是否启用',	'type'=>'checkbox',		'label'=>'是否启用spay支付宝免签',	'default'=>'',),
				'title'			=>array('title'=>'支付宝(spay)','type'=>'text',			'label'=>'前台用户看见的名称',		'default'=>'spay支付宝免签',),
				'description'	=>array('title'=>'描述',		'type'=>'textarea',		'label'=>'支付方式的描述',			'default'=>'通过支付宝付款',),
				'alipayUid'		=>array('title'=>'id',			'type'=>'text',			'label'=>'',						'default'=>'',),
				'alipayKey'		=>array('title'=>'key',			'type'=>'text',			'label'=>'',						'default'=>'',)
			);
		} 
		
		function payment_fields(){
			if($this->description) echo wpautop(wptexturize($this->description));
		}

		function process_payment($order_id){
			date_default_timezone_set('Asia/Shanghai');
			$info=get_option('woocommerce_spayalipay_settings');
			$order = new WC_Order($order_id);
			$order->reduce_order_stock();
			global $woocommerce;
			$woocommerce->cart->empty_cart();
			
			$data['service'] = 'create_direct_pay_by_user';     
			$data['total_fee'] = number_format($order->get_total(), 2, '.', '');
			$data['partner']= $info['alipayUid'];    //spay合作者id
			$data['notify_url']=  plugins_url('', __FILE__ ).'/pay_ok.php';
			$data['return_url']=  $data['notify_url']; 
			$data['out_trade_no']= 'CIP'.$order_id;
			return array('result' => 'success', 'redirect' => spayalipayPay($data,$info['alipayKey']));
		}
	}
}
function spayalipayPay($data,$key) {//提交支付函数
    $i=0;    $jk='';    
    ksort($data);    
    reset($data);    
    $ii=count($data);    
    foreach($data as $as1=>$as2){$i++;$jk .= $as1."=".$as2;if($ii!=$i)$jk .="&";}
    $data['sign']=md5($jk.$key);    
    return("http://www.dayyun.com/gateway.do?".http_build_query($data));    
    // header("Location: http://www.dayyun.com/gateway.do?".http_build_query($data));    
    // die('正在跳转中...');    
}