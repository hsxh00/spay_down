<?php
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
$alipay_config['partner']		= '';//合作身份者id，纯数字
$alipay_config['key']			= '';//安全检验码
?>